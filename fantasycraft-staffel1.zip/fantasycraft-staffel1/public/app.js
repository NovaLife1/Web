const $ = (s) => document.querySelector(s);
let players = [], isAdmin = false;
const roles = [
  { name: 'Projektleitung', icon: '♛', desc: 'Die Köpfe hinter dem Projekt', color: 'gold' },
  { name: 'Moderation', icon: '⚔', desc: 'Für ein faires Miteinander', color: 'violet' },
  { name: 'Spieler', icon: '✦', desc: 'Die Abenteurer dieser Welt', color: 'blue' }
];
function escapeHTML(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
async function api(url, options = {}) {
  const res = await fetch(url, { credentials: 'same-origin', ...options, headers: { ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers || {}) } });
  const data = await res.json().catch(() => ({})); if (!res.ok) throw new Error(data.error || 'Etwas ist schiefgelaufen.'); return data;
}
function card(p) {
  const initials = p.name.trim().split(/\s+/).slice(0,2).map(w => w[0]).join('').toUpperCase();
  return `<article class="player-card"><div class="avatar">${escapeHTML(initials)}</div><div class="player-name">${escapeHTML(p.name)}</div>${p.platform ? `<div class="player-handle">${escapeHTML(p.platform)}</div>` : '<div class="player-handle">Fantasycraft Staffel 1</div>'}<div class="role-pill">✦ ${escapeHTML(p.role)}</div>${isAdmin ? `<button class="delete-button" data-delete="${p.id}" aria-label="${escapeHTML(p.name)} löschen">Löschen</button>` : ''}</article>`;
}
function render() {
  const query = ($('#search').value || '').trim().toLocaleLowerCase('de');
  const filtered = players.filter(p => `${p.name} ${p.platform} ${p.role}`.toLocaleLowerCase('de').includes(query));
  $('#totalCount').textContent = players.length;
  $('#adminNotice').hidden = !isAdmin;
  $('#rosterContent').innerHTML = roles.map(r => {
    const items = filtered.filter(p => p.role === r.name);
    if (!items.length) return '';
    return `<section class="role-section ${r.color}"><div class="role-heading"><span class="role-icon">${r.icon}</span><div><h3>${r.name}</h3><p>${r.desc}</p></div><b>${items.length}</b></div><div class="player-grid">${items.map(card).join('')}</div></section>`;
  }).join('');
  $('#emptyState').hidden = filtered.length > 0;
}
async function load() { try { players = await api('/api/players'); render(); } catch (e) { $('#rosterContent').innerHTML = `<div class="error-box">${escapeHTML(e.message)} Bitte lade die Seite neu.</div>`; } }
function toast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 2800); }
function showModal() { $('#loginModal').hidden = false; $('#loginMessage').textContent = ''; setTimeout(() => $('#username').focus(), 50); }
function hideModal() { $('#loginModal').hidden = true; $('#loginForm').reset(); }
$('#loginTrigger').addEventListener('click', async () => { if (isAdmin) { try { await api('/api/logout', {method:'POST'}); isAdmin = false; $('#loginTrigger').textContent = '⚿ Admin-Login'; render(); toast('Du wurdest abgemeldet.'); } catch(e) { toast(e.message); } } else showModal(); });
$('#closeModal').addEventListener('click', hideModal);
$('#loginModal').addEventListener('click', e => { if (e.target === $('#loginModal')) hideModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') hideModal(); });
$('#loginForm').addEventListener('submit', async e => { e.preventDefault(); const btn = $('#loginForm button[type=submit]'); btn.disabled = true; $('#loginMessage').textContent = 'Anmeldung läuft …'; try { await api('/api/login', {method:'POST', body:JSON.stringify({username:$('#username').value, password:$('#password').value})}); isAdmin = true; $('#loginTrigger').textContent = '↪ Abmelden'; hideModal(); await load(); toast('Willkommen im Kontrollzentrum!'); } catch(err) { $('#loginMessage').textContent = err.message; } finally { btn.disabled = false; } });
$('#search').addEventListener('input', render);
$('#rosterContent').addEventListener('click', async e => { const btn = e.target.closest('[data-delete]'); if (!btn) return; const p = players.find(x => x.id === Number(btn.dataset.delete)); if (!p || !confirm(`„${p.name}“ wirklich aus der öffentlichen Liste löschen?`)) return; btn.disabled = true; try { await api(`/api/players/${p.id}`, {method:'DELETE'}); players = players.filter(x => x.id !== p.id); render(); toast('Teilnehmer wurde entfernt.'); } catch(err) { toast(err.message); btn.disabled = false; } });
(async () => { try { const session = await api('/api/session'); isAdmin = session.authenticated; if (isAdmin) $('#loginTrigger').textContent = '↪ Abmelden'; } catch (_) {} await load(); })();
// Refresh public list periodically so visitors see changes made by the admin.
setInterval(async () => { if (!document.hidden) { try { players = await api('/api/players'); render(); } catch (_) {} } }, 15000);
