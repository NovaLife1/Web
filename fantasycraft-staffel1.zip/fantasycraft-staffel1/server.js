require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const dbDir = path.join(__dirname, 'data');
require('fs').mkdirSync(dbDir, { recursive: true });
const PORT = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.includes('BITTE_DURCH')) {
  console.error('FEHLER: Bitte SESSION_SECRET in deiner .env setzen.'); process.exit(1);
}
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD_HASH) {
  console.error('FEHLER: Bitte ADMIN_USERNAME und ADMIN_PASSWORD_HASH in deiner .env setzen.'); process.exit(1);
}
if (production) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'], imgSrc: ["'self'", 'data:'],
  scriptSrc: ["'self'"], connectSrc: ["'self'"]
}}}));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: path.join(__dirname, 'data') }),
  name: 'fantasycraft.sid', secret: process.env.SESSION_SECRET,
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', secure: production, maxAge: 1000 * 60 * 60 * 8 }
}));
const db = new sqlite3.Database(path.join(dbDir, 'fantasycraft.sqlite'));
db.serialize(() => db.run(`CREATE TABLE IF NOT EXISTS players (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'Spieler',
 platform TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`));
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false, message: { error: 'Zu viele Loginversuche. Bitte später erneut versuchen.' } });
const writeLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const requireAdmin = (req, res, next) => req.session && req.session.admin ? next() : res.status(401).json({ error: 'Bitte zuerst anmelden.' });
// Simple same-origin check for state-changing requests.
app.use('/api', (req, res, next) => {
  if (!['POST','DELETE','PUT','PATCH'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin && origin !== `${req.protocol}://${req.get('host')}`) return res.status(403).json({ error: 'Ungültige Herkunft.' });
  next();
});
app.get('/api/players', (req, res) => db.all('SELECT id, name, role, platform, created_at FROM players ORDER BY role, name COLLATE NOCASE', (err, rows) => err ? res.status(500).json({ error: 'Teilnehmer konnten nicht geladen werden.' }) : res.json(rows)));
app.get('/api/session', (req, res) => res.json({ authenticated: !!(req.session && req.session.admin), username: req.session?.admin || null }));
app.post('/api/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string' || username.length > 100 || password.length > 200) return res.status(400).json({ error: 'Bitte Benutzername und Passwort eingeben.' });
  const userOk = username === process.env.ADMIN_USERNAME;
  let passOk = false;
  try { passOk = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH); } catch (_) {}
  if (!userOk || !passOk) return res.status(401).json({ error: 'Benutzername oder Passwort ist falsch.' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Anmeldung fehlgeschlagen.' });
    req.session.admin = process.env.ADMIN_USERNAME;
    req.session.save(err2 => err2 ? res.status(500).json({ error: 'Sitzung konnte nicht gespeichert werden.' }) : res.json({ ok: true, username: req.session.admin }));
  });
});
app.post('/api/logout', requireAdmin, (req, res) => req.session.destroy(() => { res.clearCookie('fantasycraft.sid'); res.json({ ok: true }); }));
app.post('/api/players', requireAdmin, writeLimiter, (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const role = typeof req.body?.role === 'string' ? req.body.role : 'Spieler';
  const platform = typeof req.body?.platform === 'string' ? req.body.platform.trim() : '';
  const roles = ['Spieler', 'Moderation', 'Projektleitung'];
  if (name.length < 2 || name.length > 40) return res.status(400).json({ error: 'Der Name muss 2 bis 40 Zeichen lang sein.' });
  if (!roles.includes(role)) return res.status(400).json({ error: 'Ungültige Kategorie.' });
  if (platform.length > 60) return res.status(400).json({ error: 'Plattformname darf höchstens 60 Zeichen lang sein.' });
  db.run('INSERT INTO players (name, role, platform) VALUES (?, ?, ?)', [name, role, platform], function(err) {
    if (err) return res.status(500).json({ error: 'Teilnehmer konnte nicht gespeichert werden.' });
    db.get('SELECT id, name, role, platform, created_at FROM players WHERE id = ?', [this.lastID], (e, row) => e ? res.status(500).json({ error: 'Gespeichert, aber Antwort fehlgeschlagen.' }) : res.status(201).json(row));
  });
});
app.delete('/api/players/:id', requireAdmin, writeLimiter, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: 'Ungültige Teilnehmer-ID.' });
  db.run('DELETE FROM players WHERE id = ?', [id], function(err) {
    if (err) return res.status(500).json({ error: 'Teilnehmer konnte nicht gelöscht werden.' });
    if (!this.changes) return res.status(404).json({ error: 'Teilnehmer nicht gefunden.' });
    res.json({ ok: true });
  });
});
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Fantasycraft Staffel 1 läuft auf http://localhost:${PORT}`));
