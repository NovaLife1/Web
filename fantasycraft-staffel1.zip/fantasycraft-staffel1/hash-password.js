const bcrypt = require('bcryptjs');
const password = process.argv[2];
if (!password) {
  console.error('Verwendung: npm run hash-password -- "DEIN_NEUES_PASSWORT"');
  process.exit(1);
}
bcrypt.hash(password, 12).then(hash => console.log(hash));
