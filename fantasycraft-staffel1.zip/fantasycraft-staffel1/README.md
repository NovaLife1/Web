# Fantasycraft Staffel 1

Responsive Teilnehmer-Website mit Fantasy-Hintergrund, öffentlicher Liste, Suche und geschütztem Adminbereich zum Hinzufügen und Löschen von Teilnehmern. Die Daten werden in SQLite gespeichert und sind für alle Besucher derselben veröffentlichten Website sichtbar. Die öffentliche Liste aktualisiert sich automatisch alle 15 Sekunden.

## Lokal starten

Voraussetzung: Node.js 20 oder neuer.

1. Entpacke das Projekt und öffne den Ordner im Terminal.
2. Installiere die Abhängigkeiten: `npm install`
3. Kopiere `.env.example` nach `.env`.
4. Erzeuge einen Passwort-Hash: `npm run hash-password -- "HIER_DEIN_NEUES_PASSWORT"`
5. Trage den ausgegebenen Hash in `ADMIN_PASSWORD_HASH` in `.env` ein. Setze `ADMIN_USERNAME` auf deinen gewünschten Benutzernamen und `SESSION_SECRET` auf eine lange zufällige Zeichenfolge.
6. Starte mit `npm start` und öffne `http://localhost:3000`.

## Veröffentlichung

Auf einem Node.js-Host deployen, `npm install` als Build-Schritt und `npm start` als Startbefehl setzen. Die Variablen aus `.env` als geheime Umgebungsvariablen im Hosting-Dashboard eintragen (nicht die `.env` veröffentlichen). `NODE_ENV=production` setzen und HTTPS aktivieren. Der Host muss dauerhaften Speicher für `data/fantasycraft.sqlite` und `data/sessions.sqlite` bieten; bei mehreren Server-Instanzen ist ein gemeinsamer Datenbank-/Session-Dienst nötig.

## Sicherheit

Das Passwort ist absichtlich nicht im Quellcode hinterlegt. Verwende für die veröffentlichte Seite ein neues, einzigartiges Passwort und teile es nicht öffentlich. Falls du das im Chat genannte Passwort auch anderswo verwendest, ändere es dort ebenfalls. Diese Vorlage ist ein Starterprojekt; vor einer größeren öffentlichen Nutzung sollten Backups, Monitoring und ein robuster CSRF-Schutz ergänzt werden.
